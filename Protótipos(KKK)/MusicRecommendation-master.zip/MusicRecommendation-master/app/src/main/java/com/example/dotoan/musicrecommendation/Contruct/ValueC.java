package com.example.dotoan.musicrecommendation.Contruct;

/**
 * Created by DOTOAN on 11/17/2017.
 */

public class ValueC {
    private int user;
    private double distance;

    public ValueC() {
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }
}
